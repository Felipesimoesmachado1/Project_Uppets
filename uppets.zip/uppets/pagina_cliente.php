<?php
session_start();
require_once 'conexao.php';

if (!isset($_SESSION['id_cliente'])) {
    header('Location: login.php');
    exit();
}

$id_cliente = $_SESSION['id_cliente'];
$nome       = $_SESSION['nome_cliente'] ?? '';

// buscar agendamentos futuros
$stmt = $pdo->prepare('SELECT id, data, horario, status, motivo FROM agendamentos WHERE cliente_id = ? ORDER BY data, horario');
$stmt->execute([$id_cliente]);
$agendamentos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Página do Cliente | UPPETS</title>
  <style>
    /* Reset */
    * {
      box-sizing: border-box;
      margin: 0; padding: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      scroll-behavior: smooth;
    }
    body {
      background: linear-gradient(135deg, #e0f2f1, #ffffff);
      min-height: 100vh;
      padding: 30px 20px;
      color: #333;
      display: flex;
      flex-direction: column;
      align-items: center;
    }
    /* Fade-in animation */
    @keyframes fadeSlideIn {
      from {
        opacity: 0;
        transform: translateY(15px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    .fade-in {
      animation: fadeSlideIn 0.8s ease forwards;
    }

    .header {
      font-size: 2.8rem;
      font-weight: 700;
      color: #00796b;
      margin-bottom: 30px;
      text-shadow: 1px 1px 3px rgba(0,0,0,0.1);
      user-select: none;
      transition: color 0.3s ease;
      cursor: default;
      animation-delay: 0.2s;
      animation-fill-mode: forwards;
      opacity: 0;
      animation-name: fadeSlideIn;
      animation-duration: 1s;
    }
    .header:hover {
      color: #004d40;
    }
    .container {
      background: #fff;
      width: 100%;
      max-width: 900px;
      border-radius: 15px;
      box-shadow: 0 6px 25px rgba(0,0,0,0.1);
      padding: 25px 30px;
      box-sizing: border-box;
      transition: box-shadow 0.3s ease;
      animation: fadeSlideIn 1s ease forwards;
      animation-delay: 0.3s;
      opacity: 0;
    }
    .container:hover {
      box-shadow: 0 10px 40px rgba(0,0,0,0.15);
    }
    /* Botões principais */
    .btn {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      background-color: #00796b;
      color: white;
      font-weight: 700;
      padding: 12px 22px;
      margin: 5px 10px 20px 0;
      border-radius: 10px;
      text-decoration: none;
      box-shadow: 0 4px 12px rgba(0,121,107,0.3);
      transition: background-color 0.3s ease, box-shadow 0.3s ease, transform 0.2s ease;
      user-select: none;
      cursor: pointer;
      position: relative;
      overflow: hidden;
      font-size: 1rem;
    }
    .btn svg {
      fill: white;
      width: 18px;
      height: 18px;
    }
    .btn:hover {
      background-color: #004d40;
      box-shadow: 0 6px 18px rgba(0,77,64,0.5);
      transform: translateY(-2px);
    }
    .btn:active {
      transform: translateY(0);
      box-shadow: 0 4px 10px rgba(0,121,107,0.3);
    }
    /* Tooltip */
    .btn[title]:hover::after {
      content: attr(title);
      position: absolute;
      bottom: 120%;
      left: 50%;
      transform: translateX(-50%);
      background: #004d40;
      color: white;
      padding: 6px 10px;
      border-radius: 5px;
      font-size: 0.85rem;
      white-space: nowrap;
      opacity: 0.9;
      pointer-events: none;
      user-select: none;
      transition: opacity 0.3s ease;
      z-index: 10;
    }
    /* Loading spinner for cancel button */
    .btn.loading {
      pointer-events: none;
      color: transparent;
    }
    .btn.loading::after {
      content: '';
      position: absolute;
      left: 50%;
      top: 50%;
      width: 20px;
      height: 20px;
      margin: -10px 0 0 -10px;
      border: 3px solid white;
      border-top: 3px solid #004d40;
      border-radius: 50%;
      animation: spin 1s linear infinite;
      z-index: 20;
    }
    @keyframes spin {
      to { transform: rotate(360deg); }
    }
    /* Título seção */
    h2 {
      color: #004d40;
      margin-bottom: 15px;
      user-select: none;
      animation: fadeSlideIn 1s ease forwards;
      animation-delay: 0.5s;
      opacity: 0;
    }
    /* Texto para nenhum agendamento */
    p {
      font-size: 1.1rem;
      text-align: center;
      color: #666;
      padding: 20px 0;
      user-select: none;
      animation: fadeSlideIn 1s ease forwards;
      animation-delay: 0.5s;
      opacity: 0;
    }
    /* Tabela */
    table {
      width: 100%;
      border-collapse: collapse;
      border-radius: 10px;
      overflow: hidden;
      box-shadow: 0 4px 15px rgba(0,0,0,0.05);
      background-color: #fafafa;
      animation: fadeSlideIn 1s ease forwards;
      animation-delay: 0.6s;
      opacity: 0;
    }
    thead {
      background-color: #00796b;
      color: white;
      user-select: none;
    }
    th, td {
      padding: 14px 18px;
      text-align: center;
      border-bottom: 1px solid #ddd;
      font-size: 1rem;
    }
    tbody tr:hover {
      background-color: #c8e6c9;
      transition: background-color 0.3s ease;
      cursor: default;
    }
    tbody tr:nth-child(even) {
      background-color: #f1f8e9;
    }
    /* Status color badge + icon */
    .status {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      font-weight: 700;
      padding: 4px 12px;
      border-radius: 20px;
      font-size: 0.9rem;
      user-select: none;
    }
    .status.agendado {
      background-color: #81c784;
      color: #2e7d32;
    }
    .status.cancelado {
      background-color: #e57373;
      color: #b71c1c;
    }
    .status.concluido {
      background-color: #64b5f6;
      color: #0d47a1;
    }
    .status svg {
      width: 16px;
      height: 16px;
      fill: currentColor;
    }
    /* Link ação cancelar */
    a.cancel-link {
      color: #d32f2f;
      font-weight: 600;
      text-decoration: none;
      transition: color 0.3s ease;
      user-select: none;
      cursor: pointer;
      position: relative;
    }
    a.cancel-link:hover {
      color: #9a0007;
      text-decoration: underline;
    }
    /* Responsividade */
    @media (max-width: 700px) {
      .container {
        padding: 15px 20px;
      }
      table, thead, tbody, th, td, tr {
        display: block;
      }
      thead tr {
        display: none;
      }
      tbody tr {
        margin-bottom: 20px;
        background-color: #e0f2f1;
        border-radius: 10px;
        padding: 15px;
        box-shadow: 0 3px 10px rgba(0,0,0,0.1);
      }
      tbody td {
        text-align: right;
        padding-left: 50%;
        position: relative;
        font-size: 0.95rem;
      }
      tbody td::before {
        content: attr(data-label);
        position: absolute;
        left: 15px;
        width: 45%;
        padding-left: 10px;
        font-weight: 700;
        text-align: left;
        color: #004d40;
        user-select: none;
      }
      tbody td:last-child {
        text-align: center;
        padding-left: 0;
      }
    }
    /* Botão voltar topo */
    #btn-topo {
      position: fixed;
      bottom: 40px;
      right: 40px;
      background-color: #00796b;
      border: none;
      padding: 12px 18px;
      border-radius: 50%;
      cursor: pointer;
      box-shadow: 0 4px 12px rgba(0,121,107,0.4);
      transition: background-color 0.3s ease, box-shadow 0.3s ease;
      display: none;
      z-index: 999;
    }
    #btn-topo:hover {
      background-color: #004d40;
      box-shadow: 0 6px 20px rgba(0,77,64,0.6);
    }
    #btn-topo svg {
      fill: white;
      width: 24px;
      height: 24px;
    }
  </style>
</head>
<body>
  <div class="header fade-in">Olá <?php echo htmlspecialchars($nome); ?>!</div>
  <div class="container fade-in">

    <div style="text-align:center;margin-bottom:20px;">
      <a href="agendamento.php" class="btn" title="Agendar nova consulta">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M19 4h-1V2h-2v2H8V2H6v2H5a2 2 0 00-2 2v12a2 2 0 002 2h14a2 2 0 002-2V6a2 2 0 00-2-2zM5 20V9h14v11z"/></svg>
        Agendar Consulta
      </a>
      <a href="historico_agendamento.php" class="btn" title="Ver histórico de agendamentos">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M13 3a9 9 0 109 9h-2a7 7 0 11-7-7z"/><path d="M12 7v6l4 2"/></svg>
        Histórico
      </a>
      <a href="editar_perfil.php" class="btn" title="Editar suas informações pessoais">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14.7 3a4 4 0 014 4c0 2.21-1.79 4-4 4s-4-1.79-4-4a4 4 0 014-4zM5 21v-1c0-2.67 5.33-4 7-4s7 1.33 7 4v1H5z"/></svg>
        Editar Perfil
      </a>
      <a href="logout.php" class="btn" title="Sair da sua conta">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M16 13v-2H7V8l-5 4 5 4v-3zM20 3h-8v2h8v14h-8v2h8a2 2 0 002-2V5a2 2 0 00-2-2z"/></svg>
        Sair
      </a>
    </div>

    <h2>Próximos Agendamentos</h2>

    <?php if (!$agendamentos): ?>
      <p>Nenhum agendamento encontrado.</p>
    <?php else: ?>
      <table>
        <thead>
          <tr>
            <th>Data</th>
            <th>Horário</th>
            <th>Status</th>
            <th>Motivo</th>
            <th>Ações</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($agendamentos as $ag): 
          // Determinar classe e ícone para status
          $status_class = '';
          $status_icon = '';
          switch(strtolower($ag['status'])) {
            case 'agendado':
              $status_class = 'agendado';
              $status_icon = '<svg viewBox="0 0 24 24" aria-hidden="true" style="width:16px;height:16px;fill:#2e7d32;"><path d="M9 16.2l-3.5-3.5 1.4-1.4L9 13.4l7.1-7.1 1.4 1.4z"/></svg>';
              break;
            case 'cancelado':
              $status_class = 'cancelado';
              $status_icon = '<svg viewBox="0 0 24 24" aria-hidden="true" style="width:16px;height:16px;fill:#b71c1c;"><path d="M18 6L6 18M6 6l12 12"/></svg>';
              break;
            case 'concluido':
              $status_class = 'concluido';
              $status_icon = '<svg viewBox="0 0 24 24" aria-hidden="true" style="width:16px;height:16px;fill:#0d47a1;"><path d="M9 16.2l-3.5-3.5 1.4-1.4L9 13.4l7.1-7.1 1.4 1.4z"/></svg>';
              break;
            default:
              $status_class = '';
              $status_icon = '';
          }
          ?>
          <tr>
            <td data-label="Data"><?php echo date('d/m/Y', strtotime($ag['data'])); ?></td>
            <td data-label="Horário"><?php echo substr($ag['horario'],0,5); ?></td>
            <td data-label="Status"><span class="status <?php echo $status_class; ?>"><?php echo $status_icon; ?> <?php echo ucfirst($ag['status']); ?></span></td>
            <td data-label="Motivo"><?php echo htmlspecialchars($ag['motivo']); ?></td>
            <td data-label="Ações">
              <?php if (strtolower($ag['status']) == 'agendado'): ?>
                <a href="cancelar_agendamento.php?id=<?php echo $ag['id']; ?>" 
                   class="cancel-link" 
                   title="Cancelar este agendamento"
                   onclick="return confirmCancelar(this);"
                >Cancelar</a>
              <?php else: ?>
                —
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>

  <!-- Botão voltar ao topo -->
  <button id="btn-topo" title="Voltar ao topo" aria-label="Voltar ao topo">
    <svg viewBox="0 0
