<?php
session_start();
require_once 'conexao.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: login.php');
    exit();
}

$email = trim($_POST['email'] ?? '');
$senha = $_POST['senha'] ?? '';

$stmt = $pdo->prepare('SELECT id, senha, nome FROM clientes WHERE email = ?');
$stmt->execute([$email]);
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);

if ($usuario && password_verify($senha, $usuario['senha'])) {
    $_SESSION['id_cliente'] = $usuario['id'];
    $_SESSION['nome_cliente'] = $usuario['nome'];
    header('Location: pagina_cliente.php');
    exit();
}

header('Location: login.php?erro=1');
exit();
?>
