<?php
session_start();
require_once 'conexao.php';

if (!isset($_SESSION['id_cliente'])) {
    header('Location: login.php');
    exit();
}

$id_cliente = $_SESSION['id_cliente'];

$stmt = $pdo->prepare('SELECT data, horario, motivo, status FROM agendamentos WHERE cliente_id = ? ORDER BY data DESC');
$stmt->execute([$id_cliente]);
$agendamentos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Histórico de Agendamentos | UPPETS</title>

  <!-- Bootstrap + Animate.css -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>

  <style>
    body {
      background: linear-gradient(to right, #e0f7fa, #ffffff);
      font-family: 'Segoe UI', sans-serif;
      padding: 20px;
    }

    .header {
      text-align: center;
      font-size: 1.8rem;
      color: #00796b;
      font-weight: bold;
      margin-bottom: 30px;
      animation: fadeInDown 0.7s ease;
    }

    .container {
      max-width: 900px;
      margin: 0 auto;
      background: #fff;
      padding: 30px;
      border-radius: 15px;
      box-shadow: 0 0 15px rgba(0,0,0,0.1);
      animation: fadeInUp 0.8s ease;
    }

    table th {
      background-color: #e0f2f1;
    }

    .btn-voltar {
      background-color: #00796b;
      color: #fff;
      border: none;
      padding: 10px 20px;
      border-radius: 8px;
      text-decoration: none;
    }

    .btn-voltar:hover {
      background-color: #004d40;
    }

    .badge-status {
      padding: 6px 12px;
      border-radius: 6px;
      font-size: 0.9rem;
    }

    .badge-pendente { background: #ffca28; color: #000; }
    .badge-realizado { background: #66bb6a; color: #fff; }
    .badge-cancelado { background: #ef5350; color: #fff; }

    @keyframes fadeInDown {
      from { opacity: 0; transform: translateY(-20px); }
      to   { opacity: 1; transform: translateY(0); }
    }

    @keyframes fadeInUp {
      from { opacity: 0; transform: translateY(20px); }
      to   { opacity: 1; transform: translateY(0); }
    }
  </style>
</head>
<body>

  <div class="header">📖 Histórico de Agendamentos</div>

  <div class="container">

    <a href="pagina_cliente.php" class="btn-voltar mb-3 d-inline-block">← Voltar</a>

    <?php if (!$agendamentos): ?>
      <div class="alert alert-warning text-center">Não há agendamentos anteriores.</div>
    <?php else: ?>
      <div class="table-responsive">
        <table class="table table-bordered table-hover text-center">
          <thead class="table-light">
            <tr>
              <th>Data</th>
              <th>Hora</th>
              <th>Motivo</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($agendamentos as $ag): ?>
              <tr>
                <td><?= date('d/m/Y', strtotime($ag['data'])) ?></td>
                <td><?= substr($ag['horario'], 0, 5) ?></td>
                <td><?= htmlspecialchars($ag['motivo']) ?></td>
                <td>
                  <?php
                    $status = strtolower($ag['status']);
                    $badgeClass = match ($status) {
                      'pendente' => 'badge-pendente',
                      'realizado' => 'badge-realizado',
                      'cancelado' => 'badge-cancelado',
                      default => 'bg-secondary text-white'
                    };
                  ?>
                  <span class="badge badge-status <?= $badgeClass ?>">
                    <?= ucfirst($ag['status']) ?>
                  </span>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
