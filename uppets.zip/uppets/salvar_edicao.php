<?php
session_start();
require_once 'conexao.php';

// Verifica se cliente está logado
if (!isset($_SESSION['id_cliente'])) {
    header('Location: login.php');
    exit();
}

$id_cliente = $_SESSION['id_cliente'];

// Recebe e sanitiza dados do formulário
$nome  = trim($_POST['nome'] ?? '');
$email = trim($_POST['email'] ?? '');
$cpf   = trim($_POST['cpf'] ?? '');

// Validação básica (pode ampliar se quiser)
$erros = [];

if (empty($nome)) {
    $erros[] = "O nome é obrigatório.";
}

if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $erros[] = "Informe um e-mail válido.";
}

if (empty($cpf) || !preg_match('/^\d{11}$/', $cpf)) {
    $erros[] = "CPF deve conter 11 dígitos numéricos.";
}

// Se houver erros, volta para o formulário com mensagem
if ($erros) {
    $erro_msg = implode(" ", $erros);
    echo "<script>alert('Erro: $erro_msg'); window.history.back();</script>";
    exit();
}

// Verifica se o e-mail ou CPF já estão usados por outro cliente
$sqlCheck = "SELECT id FROM clientes WHERE (email = ? OR cpf = ?) AND id != ?";
$stmtCheck = $conn->prepare($sqlCheck);
$stmtCheck->bind_param("ssi", $email, $cpf, $id_cliente);
$stmtCheck->execute();
$resultCheck = $stmtCheck->get_result();

if ($resultCheck->num_rows > 0) {
    echo "<script>alert('E-mail ou CPF já cadastrado para outro usuário.'); window.history.back();</script>";
    exit();
}

// Atualiza os dados no banco
$sqlUpdate = "UPDATE clientes SET nome = ?, email = ?, cpf = ? WHERE id = ?";
$stmtUpdate = $conn->prepare($sqlUpdate);
$stmtUpdate->bind_param("sssi", $nome, $email, $cpf, $id_cliente);

if ($stmtUpdate->execute()) {
    echo "<script>alert('Perfil atualizado com sucesso!'); window.location.href = 'pagina_cliente.php';</script>";
} else {
    echo "<script>alert('Erro ao atualizar perfil. Tente novamente.'); window.history.back();</script>";
}

$conn->close();
?>
