<?php
session_start();
if (isset($_SESSION['id_cliente'])) {
    header('Location: pagina_cliente.php');
    exit();
}
$msg = '';
$classe = '';
if (isset($_GET['erro']) && $_GET['erro'] === '1') {
    $msg = 'Usuário ou senha inválidos.';
    $classe = 'erro';
}
if (isset($_GET['cadastro']) && $_GET['cadastro'] === 'ok') {
    $msg = 'Cadastro realizado com sucesso! Faça login abaixo.';
    $classe = 'sucesso';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Área do Cliente | UPPETS</title>
<style>
:root{
    --verde:#00796b;
    --fundo:#e0f2f1;
}
*{box-sizing:border-box;font-family:'Segoe UI',sans-serif;margin:0;padding:0}
body{background:linear-gradient(135deg,var(--fundo),#fff);min-height:100vh;display:flex;flex-direction:column;align-items:center;padding:40px 20px}
.wrapper{width:100%;max-width:420px;background:#fff;padding:30px 25px;border-radius:18px;box-shadow:0 6px 20px rgba(0,0,0,.1)}
.tabs{display:flex;margin-bottom:25px}
.tab{flex:1;text-align:center;padding:10px 0;cursor:pointer;font-weight:600;border-bottom:3px solid transparent;transition:color .2s,border-color .2s}
.tab.ativa{color:var(--verde);border-color:var(--verde)}
.form{display:none}
.form.ativa{display:block}
input,button{width:100%;padding:12px;font-size:1rem;border-radius:8px;border:1px solid #ccc;margin-bottom:15px}
button{background:var(--verde);color:#fff;border:none;font-weight:600;cursor:pointer}
button:hover{opacity:.9}
.alerta{margin-bottom:15px;padding:10px;border-radius:6px;text-align:center}
.alerta.sucesso{background:#c8e6c9;color:#256029}
.alerta.erro{background:#ffebee;color:#c62828}
</style>
</head>
<body>
<div class="wrapper">
    <?php if($msg): ?>
      <div class="alerta <?=$classe?>"><?= $msg ?></div>
    <?php endif; ?>

    <div class="tabs">
        <div class="tab ativa" data-alvo="login">Entrar</div>
        <div class="tab" data-alvo="cadastro">Cadastrar</div>
    </div>

    <div id="login" class="form ativa">
        <form action="verifica_login.php" method="POST">
            <input type="email" name="email" placeholder="E‑mail" required>
            <input type="password" name="senha" placeholder="Senha" required>
            <button type="submit">Entrar</button>
        </form>
    </div>

    <div id="cadastro" class="form">
        <form action="salvar_usuario.php" method="POST">
            <input type="text" name="nome" placeholder="Nome completo" required>
            <input type="email" name="email" placeholder="E‑mail" required>
            <input type="text" name="cpf" placeholder="CPF" required>
            <input type="password" name="senha" placeholder="Senha" required>
            <button type="submit">Cadastrar</button>
        </form>
    </div>
</div>

<script>
const tabs=document.querySelectorAll('.tab');
const forms=document.querySelectorAll('.form');
tabs.forEach(t=>t.addEventListener('click',()=>{
   tabs.forEach(tab=>tab.classList.remove('ativa'));
   t.classList.add('ativa');
   forms.forEach(f=>f.classList.remove('ativa'));
   document.getElementById(t.dataset.alvo).classList.add('ativa');
}));
</script>
</body>
</html>
