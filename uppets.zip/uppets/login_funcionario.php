<?php
session_start();
if (isset($_SESSION['id_funcionario'])) {
    header('Location: painel_funcionario.php');
    exit();
}
$msg = '';
if (isset($_GET['erro'])) $msg = 'Usuário ou senha inválidos.';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Funcionário | UPPETS</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #e0f7fa, #ffffff);
            height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .header {
            font-size: 2rem;
            font-weight: bold;
            color: #00796b;
            margin-bottom: 30px;
            text-align: center;
            animation: fadeInDown 1s ease;
        }

        .container {
            width: 100%;
            max-width: 400px;
            padding: 30px;
            border-radius: 15px;
            background-color: #ffffff;
            box-shadow: 0 0 15px rgba(0, 121, 107, 0.2);
            animation: fadeInUp 1s ease;
        }

        form .card {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        label {
            font-weight: bold;
            color: #00796b;
        }

        input[type="email"],
        input[type="password"] {
            padding: 12px;
            border: 1px solid #b2dfdb;
            border-radius: 8px;
            background-color: #f1fefc;
            transition: all 0.3s ease;
        }

        input:focus {
            outline: none;
            border-color: #00796b;
            box-shadow: 0 0 5px rgba(0, 150, 136, 0.3);
        }

        button {
            background-color: #009688;
            color: #fff;
            padding: 12px;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        button:hover {
            background-color: #00796b;
        }

        p {
            margin-bottom: 10px;
            color: red;
            text-align: center;
        }

        @keyframes fadeInDown {
            from { opacity: 0; transform: translateY(-30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 480px) {
            .container {
                padding: 20px;
            }

            .header {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="header">Login do Funcionário</div>
    <div class="container">
        <?php if ($msg): ?><p><?php echo $msg; ?></p><?php endif; ?>
        <form action="verificar_login_funcionario.php" method="POST">
            <div class="card">
                <label for="email">E-mail:</label>
                <input type="email" name="email" id="email" required>
                
                <label for="senha">Senha:</label>
                <input type="password" name="senha" id="senha" required minlength="6">
                
                <button type="submit">Entrar</button>
            </div>
        </form>
    </div>
</body>
</html>
