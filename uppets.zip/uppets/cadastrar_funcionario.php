<?php
session_start();
if (!isset($_SESSION['id_funcionario'])) {
    header('Location: login_funcionario.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cadastrar Funcionário | UPPETS</title>

  <!-- Bootstrap + Animate.css -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>

  <style>
    body {
      background: linear-gradient(to right, #e0f7fa, #ffffff);
      font-family: 'Segoe UI', sans-serif;
      padding: 20px;
    }

    .header {
      text-align: center;
      font-size: 2rem;
      color: #00796b;
      font-weight: bold;
      margin-bottom: 30px;
      animation: fadeInDown 0.6s ease-in-out;
    }

    .container {
      max-width: 700px;
      margin: 0 auto;
      background: #fff;
      padding: 30px;
      border-radius: 15px;
      box-shadow: 0 0 15px rgba(0,0,0,0.1);
      animation: fadeInUp 0.7s ease-in-out;
    }

    label {
      font-weight: 500;
      margin-top: 12px;
    }

    input[type="text"],
    input[type="email"],
    input[type="password"] {
      border-radius: 8px;
    }

    .btn-cadastrar {
      background-color: #00796b;
      color: #fff;
      border: none;
      padding: 12px 25px;
      margin-top: 20px;
      border-radius: 8px;
      font-weight: 500;
    }

    .btn-cadastrar:hover {
      background-color: #004d40;
    }

    .btn-voltar {
      display: inline-block;
      margin-top: 25px;
      text-decoration: none;
      background-color: #cfd8dc;
      color: #000;
      padding: 10px 20px;
      border-radius: 8px;
    }

    .btn-voltar:hover {
      background-color: #b0bec5;
    }

    @keyframes fadeInDown {
      from { opacity: 0; transform: translateY(-20px); }
      to   { opacity: 1; transform: translateY(0); }
    }

    @keyframes fadeInUp {
      from { opacity: 0; transform: translateY(20px); }
      to   { opacity: 1; transform: translateY(0); }
    }
  </style>
</head>
<body>

  <div class="header">👨‍⚕️ Cadastro de Funcionário</div>

  <div class="container">
    <form action="salvar_funcionario.php" method="POST">
      <div class="mb-3">
        <label for="nome" class="form-label">Nome Completo:</label>
        <input type="text" class="form-control" name="nome" id="nome" required>
      </div>

      <div class="mb-3">
        <label for="email" class="form-label">E-mail:</label>
        <input type="email" class="form-control" name="email" id="email" required>
      </div>

      <div class="mb-3">
        <label for="cpf" class="form-label">CPF:</label>
        <input type="text" class="form-control" name="cpf" id="cpf" required pattern="\d{11}" maxlength="11">
      </div>

      <div class="mb-3">
        <label for="senha" class="form-label">Senha:</label>
        <input type="password" class="form-control" name="senha" id="senha" required minlength="6">
      </div>

      <div class="mb-3">
        <label for="confirmar_senha" class="form-label">Confirmar Senha:</label>
        <input type="password" class="form-control" name="confirmar_senha" id="confirmar_senha" required minlength="6">
      </div>

      <button type="submit" class="btn btn-cadastrar w-100">✅ Cadastrar Funcionário</button>
    </form>

    <div class="text-center">
      <a href="painel_funcionario.php" class="btn-voltar mt-3">← Voltar ao Painel</a>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
