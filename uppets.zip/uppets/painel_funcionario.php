<?php
session_start();
require_once 'conexao.php';

if (!isset($_SESSION['id_funcionario'])) {
    header('Location: login_funcionario.php');
    exit();
}

$nome_func = $_SESSION['nome_funcionario'] ?? '';

// Filtro de status
$statusFiltro = $_GET['status'] ?? '';
$valoresStatus = ['agendado', 'finalizado', 'cancelado'];

$params = [];
$sql = 'SELECT a.id,
               c.nome  AS cliente,
               a.data,
               a.horario,
               a.motivo,
               a.status
        FROM agendamentos a
        JOIN clientes c ON c.id = a.cliente_id
        WHERE 1';

if (in_array($statusFiltro, $valoresStatus)) {
    $sql      .= ' AND a.status = ?';
    $params[]  = $statusFiltro;
}

$sql .= ' ORDER BY a.data, a.horario';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$agendamentos = $stmt->fetchAll(PDO::FETCH_ASSOC);

// CSRF token
if (empty($_SESSION['token'])) {
    $_SESSION['token'] = bin2hex(random_bytes(32));
}
$token = $_SESSION['token'];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Painel do Funcionário | UPPETS</title>

  <!-- Bootstrap + Animate.css -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>

  <style>
    body {
      background: linear-gradient(to right, #e0f7fa, #ffffff);
      font-family: 'Segoe UI', sans-serif;
    }
    .header {
      background-color: #00796b;
      color: #fff;
      padding: 20px;
      text-align: center;
      font-size: 1.5rem;
      font-weight: bold;
    }
    .container {
      background: #fff;
      margin-top: 40px;
      padding: 30px;
      border-radius: 15px;
      box-shadow: 0 0 20px rgba(0,0,0,0.1);
      animation: fadeIn 0.8s ease-in;
    }
    table th {
      background-color: #e3f2fd;
    }
    .btn-sair {
      background-color: #e53935;
      color: #fff;
    }
    .btn-fin {
      background-color: #43cea2;
      color: #fff;
    }
    .btn-can {
      background-color: #ff7043;
      color: #fff;
    }
    .filtros select {
      padding: 6px 12px;
      border-radius: 6px;
    }
    @keyframes fadeIn {
      from {opacity: 0; transform: translateY(20px);}
      to {opacity: 1; transform: translateY(0);}
    }
  </style>
</head>
<body>

  <div class="header animate__animated animate__fadeInDown">
    Bem-vindo, <?= htmlspecialchars($nome_func) ?>!
  </div>

  <div class="container animate__animated animate__fadeInUp">

    <div class="d-flex justify-content-between align-items-center mb-3">
      <h2 class="text-primary">📅 Agendamentos</h2>
      <a href="logout.php" class="btn btn-sair">Sair</a>
    </div>

    <!-- Filtro de status -->
    <form method="get" class="d-flex gap-3 align-items-center mb-4">
      <label for="status" class="form-label mb-0"><strong>Status:</strong></label>
      <select name="status" id="status" class="form-select w-auto" onchange="this.form.submit()">
        <option value="">Todos</option>
        <?php foreach ($valoresStatus as $st): ?>
            <option value="<?= $st ?>" <?= $st === $statusFiltro ? 'selected' : '' ?>><?= ucfirst($st) ?></option>
        <?php endforeach; ?>
      </select>
    </form>

    <?php if (!$agendamentos): ?>
      <div class="alert alert-warning text-center">Nenhum agendamento encontrado.</div>
    <?php else: ?>
      <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle text-center">
          <thead>
            <tr>
              <th>ID</th>
              <th>Cliente</th>
              <th>Data</th>
              <th>Hora</th>
              <th>Motivo</th>
              <th>Status</th>
              <th>Ações</th>
            </tr>
          </thead>
          <tbody>
          <?php foreach ($agendamentos as $ag): ?>
            <tr>
              <td><?= $ag['id'] ?></td>
              <td><?= htmlspecialchars($ag['cliente']) ?></td>
              <td><?= date('d/m/Y', strtotime($ag['data'])) ?></td>
              <td><?= substr($ag['horario'], 0, 5) ?></td>
              <td><?= htmlspecialchars($ag['motivo']) ?></td>
              <td><span class="badge bg-secondary"><?= ucfirst($ag['status']) ?></span></td>
              <td>
                <?php if ($ag['status'] === 'agendado'): ?>
                  <form method="post" action="update_status.php" class="d-inline">
                      <input type="hidden" name="token" value="<?= $token ?>">
                      <input type="hidden" name="id" value="<?= $ag['id'] ?>">
                      <button type="submit" name="acao" value="finalizar" class="btn btn-fin btn-sm">✔ Finalizar</button>
                  </form>
                  <form method="post" action="update_status.php" class="d-inline">
                      <input type="hidden" name="token" value="<?= $token ?>">
                      <input type="hidden" name="id" value="<?= $ag['id'] ?>">
                      <button type="submit" name="acao" value="cancelar" class="btn btn-can btn-sm">✖ Cancelar</button>
                  </form>
                <?php else: ?>
                  <span class="text-muted">—</span>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>

  </div>

  <!-- Bootstrap JS (opcional para dropdowns, modals, etc.) -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
