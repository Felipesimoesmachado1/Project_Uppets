<?php
session_start();
require_once 'conexao.php';

if (!isset($_SESSION['id_cliente'])) {
    header('Location: login.php');
    exit();
}

$id_cliente = $_SESSION['id_cliente'];

$sql = "SELECT nome, email, cpf FROM clientes WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_cliente);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $cliente = $result->fetch_assoc();
} else {
    echo "<script>alert('Cliente não encontrado.'); window.location.href='pagina_cliente.php';</script>";
    exit();
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Detalhes do Cliente | UPPETS</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap e animações -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>

    <style>
        body {
            background: linear-gradient(to right, #e0f7fa, #ffffff);
            font-family: 'Segoe UI', sans-serif;
            padding: 20px;
        }

        .header {
            text-align: center;
            font-size: 2rem;
            color: #00796b;
            font-weight: bold;
            margin-bottom: 30px;
            animation: fadeInDown 0.6s ease-in-out;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            background: #fff;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            animation: fadeInUp 0.7s ease-in-out;
        }

        .card {
            padding: 20px;
            border: 1px solid #e0f2f1;
            border-radius: 12px;
            background-color: #f9f9f9;
        }

        .card p {
            font-size: 1.1rem;
            margin-bottom: 10px;
        }

        .card strong {
            color: #004d40;
        }

        .btn-voltar {
            margin-top: 25px;
            display: inline-block;
            text-decoration: none;
            background-color: #00796b;
            color: #fff;
            padding: 10px 20px;
            border-radius: 8px;
        }

        .btn-voltar:hover {
            background-color: #004d40;
        }

        @keyframes fadeInDown {
            from { opacity: 0; transform: translateY(-20px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to   { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>

    <div class="header">👤 Detalhes do Cliente</div>

    <div class="container">
        <div class="card">
            <p><strong>Nome:</strong> <?= htmlspecialchars($cliente['nome']) ?></p>
            <p><strong>E-mail:</strong> <?= htmlspecialchars($cliente['email']) ?></p>
            <p><strong>CPF:</strong> <?= htmlspecialchars($cliente['cpf']) ?></p>
        </div>

        <div class="text-center">
            <a href="pagina_cliente.php" class="btn-voltar">← Voltar</a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
