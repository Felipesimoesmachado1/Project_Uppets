<?php
session_start();
require_once 'conexao.php';

if (!isset($_SESSION['id_cliente'])) {
    header('Location: login.php');
    exit();
}

$id_cliente = $_SESSION['id_cliente'];

$sql = "SELECT nome, email, cpf FROM clientes WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_cliente);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $cliente = $result->fetch_assoc();
} else {
    echo "<script>alert('Erro ao carregar dados.'); window.location.href='pagina_cliente.php';</script>";
    exit();
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Editar Perfil | UPPETS</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap e animações -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>

    <style>
        body {
            background: linear-gradient(to right, #e0f7fa, #ffffff);
            font-family: 'Segoe UI', sans-serif;
            padding: 20px;
        }

        .header {
            text-align: center;
            font-size: 2rem;
            color: #00796b;
            font-weight: bold;
            margin-bottom: 30px;
            animation: fadeInDown 0.6s ease-in-out;
        }

        .container {
            max-width: 600px;
            background: #fff;
            margin: 0 auto;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            animation: fadeInUp 0.7s ease-in-out;
        }

        label {
            margin-top: 15px;
            font-weight: 500;
        }

        input[type="text"], input[type="email"] {
            border-radius: 8px;
        }

        .btn-save {
            background-color: #00796b;
            color: #fff;
            border: none;
            margin-top: 20px;
            padding: 10px 20px;
            border-radius: 8px;
        }

        .btn-save:hover {
            background-color: #004d40;
        }

        .btn-cancelar {
            margin-top: 20px;
            display: inline-block;
            text-decoration: none;
            color: #00796b;
            font-weight: bold;
        }

        @keyframes fadeInDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>

    <div class="header">✏️ Editar Perfil</div>

    <div class="container">

        <form action="salvar_edicao.php" method="POST">
            <div class="mb-3">
                <label for="nome" class="form-label">Nome Completo:</label>
                <input type="text" name="nome" id="nome" class="form-control" required value="<?= htmlspecialchars($cliente['nome']) ?>">
            </div>

            <div class="mb-3">
                <label for="email" class="form-label">E-mail:</label>
                <input type="email" name="email" id="email" class="form-control" required value="<?= htmlspecialchars($cliente['email']) ?>">
            </div>

            <div class="mb-3">
                <label for="cpf" class="form-label">CPF:</label>
                <input type="text" name="cpf" id="cpf" class="form-control" required maxlength="11" pattern="\d{11}" value="<?= htmlspecialchars($cliente['cpf']) ?>">
            </div>

            <button type="submit" class="btn btn-save w-100">💾 Salvar Alterações</button>
        </form>

        <div class="text-center">
            <a href="pagina_cliente.php" class="btn-cancelar">← Cancelar</a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
