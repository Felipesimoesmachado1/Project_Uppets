-- ==========================
--  Banco UPPETS – versão 2025‑07‑01
-- ==========================

/* 1) Cria (ou reaproveita) o banco */
CREATE DATABASE IF NOT EXISTS uppets
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
USE uppets;

/* 2) Tabela de clientes */
CREATE TABLE IF NOT EXISTS clientes (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome       VARCHAR(100) NOT NULL,
  email      VARCHAR(100) UNIQUE NOT NULL,
  cpf        VARCHAR(14)  UNIQUE NOT NULL,
  senha      VARCHAR(255) NOT NULL,
  telefone   VARCHAR(20),
  criado_em  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

/* 3) Tabela de funcionários */
CREATE TABLE IF NOT EXISTS funcionarios (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome       VARCHAR(100) NOT NULL,
  email      VARCHAR(100) UNIQUE NOT NULL,
  senha      VARCHAR(255) NOT NULL,
  criado_em  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

/* 4) Tabela de agendamentos */
CREATE TABLE IF NOT EXISTS agendamentos (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  cliente_id INT UNSIGNED NOT NULL,
  data       DATE NOT NULL,
  horario    TIME NOT NULL,
  motivo     TEXT,
  status     ENUM('agendado','cancelado','finalizado') DEFAULT 'agendado',
  criado_em  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);

/* 5) Funcionário padrão (login inicial)
      Usuário: admin@uppets.com
      Senha:   uppets123
      -> troque depois no painel!                                   */
INSERT INTO funcionarios (nome, email, senha)
VALUES ('Administrador',
        'admin@uppets.com',
        '$2b$12$t.StF/TaGkerN/ZFIPp/XeE1WEBsiY2MrZq/GCLUsqEGpjXDzvm32'); -- password_hash('uppets123')
