<?php
session_start();
if (isset($_SESSION['id_cliente'])) {
    header('Location: pagina_cliente.php');
    exit();
}
if (isset($_SESSION['id_funcionario'])) {
    header('Location: painel_funcionario.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Portal de Acesso | UPPETS</title>
<style>
body{margin:0;font-family:'Segoe UI',sans-serif;background:linear-gradient(135deg,#e0f2f1,#ffffff);display:flex;justify-content:center;align-items:center;height:100vh;}
.container{display:flex;gap:40px}
.card{background:#fff;border-radius:16px;padding:40px 60px;box-shadow:0 6px 20px rgba(0,0,0,0.1);text-align:center;transition:transform 0.2s ease;}
.card:hover{transform:translateY(-4px);}
.card h2{margin-bottom:16px;color:#00796b}
button{background:#00796b;color:#fff;border:none;padding:12px 24px;border-radius:8px;font-size:1rem;cursor:pointer;transition:opacity .2s;}
button:hover{opacity:.9}
@media (max-width:600px){
  .container{flex-direction:column}
  .card{padding:30px}
}
</style>
</head>
<body>
<div class="container">
    <div class="card">
        <h2>Sou Cliente</h2>
        <button onclick="location.href='area_cliente.php'">Entrar</button>
    </div>
    <div class="card">
        <h2>Sou Atendente</h2>
        <button onclick="location.href='login_funcionario.php'">Entrar</button>
    </div>
</div>
</body>
</html>
