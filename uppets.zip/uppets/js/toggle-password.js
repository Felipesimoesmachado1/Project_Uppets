// toggle-password.js
// Mostra/oculta senhas em inputs <input type="password">
document.addEventListener('DOMContentLoaded', () => {

    function attachToggle(input) {
        const wrapper = input.parentElement;
        wrapper.style.position = 'relative';

        // botão (ícone olho)
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'toggle-pass-btn';
        btn.innerHTML = '\u{1F441}'; // ícone olho simples
        btn.setAttribute('aria-label', 'Exibir senha');
        btn.style.cssText = `
            position:absolute;
            right:8px;
            top:50%;
            transform:translateY(-50%);
            background:none;
            border:none;
            cursor:pointer;
            font-size:1.1rem;
            user-select:none;
        `;

        // padding extra no input
        input.style.paddingRight = '36px';

        btn.addEventListener('click', () => {
            const isHidden = input.getAttribute('type') === 'password';
            input.setAttribute('type', isHidden ? 'text' : 'password');
            btn.setAttribute('aria-label', isHidden ? 'Ocultar senha' : 'Exibir senha');
        });

        wrapper.appendChild(btn);
    }

    document.querySelectorAll('input[type="password"]').forEach(attachToggle);
});