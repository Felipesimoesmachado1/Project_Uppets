// interacoes.js
// Funções genéricas de interação para o site UPPETS
document.addEventListener('DOMContentLoaded', () => {

    /* ---------------------------------
       Toggle do menu mobile
    -----------------------------------*/
    const menuBtn = document.querySelector('.menu-toggle');
    const nav     = document.querySelector('nav');

    if (menuBtn && nav) {
        menuBtn.addEventListener('click', () => {
            nav.classList.toggle('open');
            menuBtn.classList.toggle('active');
        });
    }

    /* ---------------------------------
       Fechar alertas
    -----------------------------------*/
    document.querySelectorAll('.alert .alert-close').forEach(btn => {
        btn.addEventListener('click', e => {
            e.target.closest('.alert').style.display = 'none';
        });
    });

    /* ---------------------------------
       Confirmação de ações perigosas
       data-confirm="Texto da confirmação"
    -----------------------------------*/
    document.querySelectorAll('[data-confirm]').forEach(el => {
        el.addEventListener('click', e => {
            const msg = el.getAttribute('data-confirm') || 'Tem certeza?';
            if (!confirm(msg)) {
                e.preventDefault();
            }
        });
    });

    /* ---------------------------------
       Máscara simples de telefone
       <input data-mask="phone">
    -----------------------------------*/
    document.querySelectorAll('input[data-mask="phone"]').forEach(input => {
        input.addEventListener('input', e => {
            let v = e.target.value.replace(/\D/g, '').slice(0, 11);
            if (v.length >= 2) {
                v = '(' + v.substring(0, 2) + ') ' + v.substring(2);
            }
            if (v.length > 10) {
                v = v.substring(0, 10) + '-' + v.substring(10);
            } else if (v.length > 9) {
                v = v.substring(0, 9) + '-' + v.substring(9);
            }
            e.target.value = v;
        });
    });

});