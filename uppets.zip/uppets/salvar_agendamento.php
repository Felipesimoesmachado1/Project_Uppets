<?php
session_start();
require_once 'conexao.php';

if (!isset($_SESSION['id_cliente'])) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: agendamento.php');
    exit();
}

$id_cliente = $_SESSION['id_cliente'];
$data  = $_POST['data'] ?? '';
$hora  = $_POST['hora'] ?? '';
$motivo = trim($_POST['motivo'] ?? '');

if (!$data || !$hora) {
    header('Location: agendamento.php?erro=1');
    exit();
}

// checar se horário já reservado
$stmt = $pdo->prepare('SELECT COUNT(*) FROM agendamentos WHERE data = ? AND horario = ? AND status = "agendado"');
$stmt->execute([$data,$hora]);
if ($stmt->fetchColumn() > 0) {
    header('Location: agendamento.php?erro=ocupado');
    exit();
}

$stmt = $pdo->prepare('INSERT INTO agendamentos (cliente_id,data,horario,motivo) VALUES (?,?,?,?)');
$stmt->execute([$id_cliente,$data,$hora,$motivo]);

header('Location: pagina_cliente.php?agendado=ok');
exit();
?>
