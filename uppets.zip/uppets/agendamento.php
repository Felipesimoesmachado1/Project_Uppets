<?php
session_start();
if (!isset($_SESSION['id_cliente'])) {
    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Agendamento | UPPETS</title>
  <style>
    /* Reset simples */
    * {
      box-sizing: border-box;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    body {
      margin: 0;
      background: linear-gradient(135deg, #a8edea 0%, #fed6e3 100%);
      color: #333;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 20px;
    }

    .header {
      margin-top: 30px;
      font-size: 2rem;
      color: #0f4c75;
      font-weight: 700;
      text-align: center;
      text-shadow: 1px 1px 2px rgba(0,0,0,0.1);
      animation: fadeInDown 0.7s ease forwards;
    }

    .container {
      background: #fff;
      margin-top: 40px;
      padding: 30px 25px;
      max-width: 480px;
      width: 100%;
      border-radius: 16px;
      box-shadow: 0 8px 20px rgba(0,0,0,0.15);
      animation: fadeInUp 0.7s ease forwards;
    }

    form {
      display: flex;
      flex-direction: column;
    }

    label {
      font-weight: 600;
      margin-top: 20px;
      margin-bottom: 6px;
      color: #145374;
    }

    input[type="date"],
    select,
    textarea {
      padding: 12px 15px;
      border: 2px solid #c1dfe6;
      border-radius: 12px;
      font-size: 1rem;
      transition: border-color 0.3s ease;
      resize: vertical;
      min-height: 40px;
    }

    input[type="date"]:focus,
    select:focus,
    textarea:focus {
      outline: none;
      border-color: #0f4c75;
      box-shadow: 0 0 8px #0f4c75aa;
    }

    textarea {
      min-height: 100px;
      font-family: inherit;
    }

    button[type="submit"] {
      margin-top: 30px;
      background: #0f4c75;
      color: white;
      padding: 14px;
      font-size: 1.15rem;
      border: none;
      border-radius: 14px;
      cursor: pointer;
      font-weight: 700;
      box-shadow: 0 5px 15px #0f4c75bb;
      transition: background 0.3s ease;
    }

    button[type="submit"]:hover {
      background: #092f47;
      box-shadow: 0 7px 20px #092f4788;
    }

    .btn {
      display: inline-block;
      margin-top: 30px;
      padding: 10px 22px;
      background-color: #3dd4b4;
      color: #fff;
      border-radius: 12px;
      text-decoration: none;
      font-weight: 600;
      box-shadow: 0 4px 12px #3dd4b488;
      transition: background-color 0.3s ease;
    }

    .btn:hover {
      background-color: #2fa996;
    }

    /* Animações simples */
    @keyframes fadeInDown {
      from {
        opacity: 0;
        transform: translateY(-20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    /* Responsividade */
    @media (max-width: 520px) {
      .container {
        padding: 20px 15px;
      }
      button[type="submit"] {
        font-size: 1rem;
        padding: 12px;
      }
    }
  </style>
</head>
<body>

  <div class="header">Agendamento de Consulta</div>

  <div class="container">
    <form action="salvar_agendamento.php" method="POST">
      <label for="data">Data da Consulta:</label>
      <input type="date" name="data" id="data" required min="<?php echo date('Y-m-d'); ?>">

      <label for="hora">Hora da Consulta:</label>
      <select name="hora" id="hora" required>
        <?php
        for ($h = 8; $h <= 18; $h += 2) {
          $hora = str_pad($h, 2, "0", STR_PAD_LEFT) . ":00";
          echo "<option value='$hora'>$hora</option>";
        }
        ?>
      </select>

      <label for="motivo">Motivo do Atendimento:</label>
      <textarea name="motivo" id="motivo" rows="4" required placeholder="Descreva o motivo do agendamento..."></textarea>

      <button type="submit">Agendar</button>
    </form>

    <div style="text-align:center;">
      <a href="pagina_cliente.php" class="btn">Voltar à Página Inicial</a>
    </div>
  </div>

</body>
</html>
