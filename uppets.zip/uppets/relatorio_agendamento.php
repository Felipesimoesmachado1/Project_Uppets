<?php
require_once 'conexao.php';
session_start();

if (!isset($_SESSION['funcionario_id'])) {
    header('Location: login_funcionario.php');
    exit;
}

$dataFiltro = $_GET['data'] ?? '';
$statusFiltro = $_GET['status'] ?? '';

$sql = "SELECT a.id, c.nome AS cliente, a.nome_pet, a.data, a.hora, a.motivo, a.status
        FROM agendamentos a
        JOIN clientes c ON a.cliente_id = c.id
        WHERE 1";

$params = [];
if ($dataFiltro) {
    $sql .= " AND a.data = ?";
    $params[] = $dataFiltro;
}
if ($statusFiltro) {
    $sql .= " AND a.status = ?";
    $params[] = $statusFiltro;
}
$sql .= " ORDER BY a.data DESC, a.hora ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$agendamentos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Relatório de Agendamentos | UPPETS</title>

    <!-- Bootstrap + Animate.css -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    
    <style>
        body {
            background: linear-gradient(to right, #e0f2f1, #ffffff);
            font-family: 'Segoe UI', sans-serif;
        }

        .container {
            margin-top: 40px;
            background: #fff;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0,0,0,0.08);
            animation: fadeIn 0.7s ease-in-out;
        }

        h2 {
            text-align: center;
            color: #00796b;
            margin-bottom: 30px;
        }

        table th {
            background-color: #e3f2fd;
        }

        .btn-filtrar {
            background-color: #00796b;
            color: #fff;
        }

        .btn-filtrar:hover {
            background-color: #00695c;
        }

        .voltar {
            display: block;
            text-align: center;
            margin-top: 25px;
            text-decoration: none;
            color: #00796b;
            font-weight: bold;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .form-control, .form-select {
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <div class="container animate__animated animate__fadeIn">
        <h2>📄 Relatório de Agendamentos</h2>

        <form method="get" class="row g-3 mb-4">
            <div class="col-md-6">
                <label for="data" class="form-label">Filtrar por Data:</label>
                <input type="date" id="data" name="data" value="<?= htmlspecialchars($dataFiltro) ?>" class="form-control">
            </div>
            <div class="col-md-4">
                <label for="status" class="form-label">Filtrar por Status:</label>
                <select name="status" id="status" class="form-select">
                    <option value="">Todos</option>
                    <option value="pendente" <?= $statusFiltro == 'pendente' ? 'selected' : '' ?>>Pendente</option>
                    <option value="realizado" <?= $statusFiltro == 'realizado' ? 'selected' : '' ?>>Realizado</option>
                    <option value="cancelado" <?= $statusFiltro == 'cancelado' ? 'selected' : '' ?>>Cancelado</option>
                </select>
            </div>
            <div class="col-md-2 d-flex align-items-end">
                <button type="submit" class="btn btn-filtrar w-100">Filtrar</button>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-bordered table-hover align-middle text-center">
                <thead class="table-light">
                    <tr>
                        <th>ID</th>
                        <th>Cliente</th>
                        <th>Pet</th>
                        <th>Data</th>
                        <th>Hora</th>
                        <th>Motivo</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($agendamentos) > 0): ?>
                        <?php foreach ($agendamentos as $ag): ?>
                            <tr>
                                <td><?= $ag['id'] ?></td>
                                <td><?= htmlspecialchars($ag['cliente']) ?></td>
                                <td><?= htmlspecialchars($ag['nome_pet']) ?></td>
                                <td><?= date('d/m/Y', strtotime($ag['data'])) ?></td>
                                <td><?= htmlspecialchars($ag['hora']) ?></td>
                                <td><?= htmlspecialchars($ag['motivo']) ?></td>
                                <td>
                                    <?php
                                        $statusClass = [
                                            'pendente' => 'warning',
                                            'realizado' => 'success',
                                            'cancelado' => 'danger'
                                        ][$ag['status']] ?? 'secondary';
                                    ?>
                                    <span class="badge bg-<?= $statusClass ?>"><?= ucfirst($ag['status']) ?></span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" class="text-muted">Nenhum agendamento encontrado.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <a href="painel_funcionario.php" class="voltar">← Voltar ao Painel</a>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
