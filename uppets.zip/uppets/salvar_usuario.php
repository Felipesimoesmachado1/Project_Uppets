<?php
session_start();
require_once 'conexao.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: cadastro.php');
    exit();
}

$nome  = trim($_POST['nome']  ?? '');
$email = trim($_POST['email'] ?? '');
$cpf   = trim($_POST['cpf']   ?? '');
$senha = trim($_POST['senha'] ?? '');

if (!$nome || !$email || !$cpf || !$senha) {
    header('Location: cadastro.php?erro=1');
    exit();
}

$senha_hash = password_hash($senha, PASSWORD_DEFAULT);

// verificar duplicidade de email/cpf
try {
    $stmt = $pdo->prepare('INSERT INTO clientes (nome,email,cpf,senha) VALUES (?,?,?,?)');
    $stmt->execute([$nome,$email,$cpf,$senha_hash]);
    header('Location: login.php?cadastro=ok');
    exit();
} catch (PDOException $e) {
    if ($e->getCode() == 23000) { // violação de chave única
        header('Location: cadastro.php?erro=duplicado');
    } else {
        echo 'Erro: ' . $e->getMessage();
    }
    exit();
}
?>
