<?php
$host = "localhost";
$db   = "uppets";
$user = "root";      // ajuste seu usuário do banco
$pass = "";          // ajuste sua senha

// ---------- PDO ----------
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro na conexão PDO: " . $e->getMessage());
}

// ---------- MySQLi ----------
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Falha na conexão MySQLi: " . $conn->connect_error);
}
?>
