<?php
session_start();
require_once 'conexao.php';

if (!isset($_SESSION['id_cliente'])) {
    header('Location: login.php');
    exit();
}

if (!isset($_GET['id'])) {
    header('Location: pagina_cliente.php');
    exit();
}

$id_agendamento = intval($_GET['id']);
$id_cliente = $_SESSION['id_cliente'];

// verificar pertencimento
$stmt = $pdo->prepare('SELECT id FROM agendamentos WHERE id = ? AND cliente_id = ? AND status = "agendado"');
$stmt->execute([$id_agendamento,$id_cliente]);
if (!$stmt->fetch()) {
    header('Location: pagina_cliente.php?erro=perm');
    exit();
}

// cancelar
$stmt = $pdo->prepare('UPDATE agendamentos SET status = "cancelado" WHERE id = ?');
$stmt->execute([$id_agendamento]);

header('Location: pagina_cliente.php?cancelado=ok');
exit();
?>
