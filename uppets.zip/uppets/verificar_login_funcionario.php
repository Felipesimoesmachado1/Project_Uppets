<?php
session_start();
require_once 'conexao.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: login_funcionario.php');
    exit();
}

$email = trim($_POST['email'] ?? '');
$senha = $_POST['senha'] ?? '';

$stmt = $pdo->prepare('SELECT id, senha, nome FROM funcionarios WHERE email = ?');
$stmt->execute([$email]);
$func = $stmt->fetch(PDO::FETCH_ASSOC);

if ($func && password_verify($senha, $func['senha'])) {
    $_SESSION['id_funcionario'] = $func['id'];
    $_SESSION['nome_funcionario'] = $func['nome'];
    header('Location: painel_funcionario.php');
    exit();
}

header('Location: login_funcionario.php?erro=1');
exit();
?>
