<?php
session_start();
if (isset($_SESSION['id_cliente'])) {
    header('Location: pagina_cliente.php');
    exit();
}
$msg = '';
$msg_class = 'error'; // para controlar a cor do texto
if (isset($_GET['erro'])) {
    $msg = 'Usuário ou senha inválidos.';
    $msg_class = 'error';
}
if (isset($_GET['cadastro']) && $_GET['cadastro'] === 'ok') {
    $msg = 'Cadastro realizado com sucesso! Faça login.';
    $msg_class = 'success';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Login | UPPETS</title>
    <style>
        /* Reset básico */
        * {
          box-sizing: border-box;
          margin: 0;
          padding: 0;
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        /* Fundo da página */
        body {
          background: linear-gradient(135deg, #e0f2f1, #ffffff);
          min-height: 100vh;
          display: flex;
          flex-direction: column;
          justify-content: flex-start;
          align-items: center;
          padding: 40px 20px;
          color: #333;
        }
        /* Cabeçalho */
        .header {
          font-size: 2.4rem;
          font-weight: 700;
          color: #00796b;
          margin-bottom: 30px;
          text-shadow: 1px 1px 3px rgba(0,0,0,0.1);
        }
        /* Container centralizado */
        .container {
          width: 100%;
          max-width: 400px;
          background: #ffffff;
          padding: 30px 25px;
          border-radius: 15px;
          box-shadow: 0 6px 20px rgba(0,0,0,0.1);
          transition: box-shadow 0.3s ease;
        }
        .container:hover {
          box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        }
        /* Mensagens */
        .container p.message {
          font-size: 1rem;
          font-weight: 600;
          margin-bottom: 20px;
          text-align: center;
        }
        .container p.message.error {
          color: #d32f2f;
        }
        .container p.message.success {
          color: #388e3c;
        }
        /* Card interno */
        .card {
          display: flex;
          flex-direction: column;
          gap: 18px;
        }
        /* Labels */
        label {
          font-size: 1rem;
          font-weight: 600;
          color: #004d40;
          margin-bottom: 6px;
        }
        /* Inputs */
        input[type="email"],
        input[type="password"] {
          padding: 12px 15px;
          font-size: 1rem;
          border: 2px solid #b2dfdb;
          border-radius: 8px;
          transition: border-color 0.3s ease;
        }
        input[type="email"]:focus,
        input[type="password"]:focus {
          outline: none;
          border-color: #00796b;
          box-shadow: 0 0 8px rgba(0,121,107,0.4);
        }
        /* Botão */
        button[type="submit"] {
          background-color: #00796b;
          color: white;
          font-weight: 700;
          padding: 14px 0;
          border: none;
          border-radius: 10px;
          font-size: 1.1rem;
          cursor: pointer;
          box-shadow: 0 4px 10px rgba(0,121,107,0.3);
          transition: background-color 0.3s ease, box-shadow 0.3s ease;
          margin-top: 10px;
        }
        button[type="submit"]:hover {
          background-color: #004d40;
          box-shadow: 0 6px 14px rgba(0,77,64,0.5);
        }
        /* Link para cadastro */
        .card p {
          font-size: 0.95rem;
          color: #555;
          margin-top: 12px;
          text-align: center;
        }
        .card p a {
          color: #00796b;
          font-weight: 600;
          text-decoration: none;
          transition: color 0.3s ease;
        }
        .card p a:hover {
          color: #004d40;
          text-decoration: underline;
        }
        /* Responsividade */
        @media (max-width: 440px) {
          .container {
            padding: 25px 20px;
            max-width: 100%;
          }
          .header {
            font-size: 1.8rem;
          }
        }
    </style>
</head>
<body>
    <div class="header">Login do Cliente</div>
    <div class="container">
        <?php if ($msg): ?>
            <p class="message <?php echo $msg_class; ?>"><?php echo $msg; ?></p>
        <?php endif; ?>
        <form action="verifica_login.php" method="POST" autocomplete="off">
            <div class="card">
                <label for="email">E-mail:</label>
                <input type="email" name="email" id="email" required autocomplete="username" autofocus>
                
                <label for="senha">Senha:</label>
                <input type="password" name="senha" id="senha" required minlength="6" autocomplete="current-password">
                
                <button type="submit">Entrar</button>
                <p>
                    Ainda não possui conta? <a href="cadastro.php">Cadastre‑se</a>
                </p>
            </div>
        </form>
    </div>
</body>
</html>

