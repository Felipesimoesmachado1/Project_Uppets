
<?php
session_start();
if(!isset($_SESSION['id_funcionario'])){header('Location: login_funcionario.php'); exit;}
require 'conexao.php';

$id            = intval($_POST['id'] ?? 0);
$data_consulta = $_POST['data_consulta'] ?? '';
$hora_consulta = $_POST['hora_consulta'] ?? '';
$comentarios   = $_POST['comentarios']   ?? '';
$func_id       = $_SESSION['id_funcionario'];

if(!$id || !$data_consulta || !$hora_consulta){
   header('Location: painel_funcionario.php?erro=Dados obrigatórios');
   exit;
}

// registra histórico
$conn->query("INSERT INTO historico_consultas(consulta_id,status_anterior,status_novo,funcionario_id,comentario)
              SELECT id,status,'reagendada',$func_id,'$comentarios' FROM consultas WHERE id=$id");

$stmt = $conn->prepare('UPDATE consultas SET data_consulta=?, hora_consulta=?, status="reagendada", comentarios=? WHERE id=?');
$stmt->bind_param('sssi',$data_consulta,$hora_consulta,$comentarios,$id);
$stmt->execute();

header('Location: painel_funcionario.php?msg=Reagendado com sucesso');
?>
