
<?php
session_start();
require 'conexao.php';

$email = $_POST['email'] ?? '';
$senha = $_POST['senha'] ?? '';

$stmt = $conn->prepare('SELECT id,nome,senha FROM clientes WHERE email=?');
$stmt->bind_param('s', $email);
$stmt->execute();
$res = $stmt->get_result()->fetch_assoc();

if ($res && password_verify($senha, $res['senha'])) {
    $_SESSION['id_cliente']   = $res['id'];
    $_SESSION['nome_cliente'] = $res['nome'];
    header('Location: painel_cliente.php');
} else {
    header('Location: login_cliente.php?erro=Credenciais inválidas');
}
?>
