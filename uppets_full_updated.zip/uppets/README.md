# Estrutura Base – UPPETS (2025-07-02)

Este pacote contém a **estrutura mínima** para rodar localmente em XAMPP.

## Como usar
1. Copie a pasta `uppets_struct` para `C:/xampp/htdocs/uppets`.
2. Execute o script `sql/structure.sql` no phpMyAdmin.
3. Ajuste as credenciais em `conexao.php` se necessário.
4. Instale dependências:
   ```bash
   cd uppets
   composer install      # para PHPMailer / FPDF
   ```
5. Abra `http://localhost/uppets` no navegador.

## Pastas
- **api/** – endpoints AJAX (JSON)
- **css/** – folhas de estilo
- **js/**  – scripts front-end
- **sql/** – scripts de banco
- **vendor/** – gerenciado pelo Composer

## Próximos Passos
- Implementar a lógica de cada _processar_*.php
- Adicionar design customizado
- Integrar PHPMailer em `email_helper.php`

## Atualização – 2025-07-02
* Conexão unificada via **PDO + MySQLi** (`conexao.php`)
* Script SQL completo revisado (`sql/structure.sql`)
* Login de funcionário seguro com PDO (`verifica_login_funcionario.php`)
* Endpoint `api/stats_consultas.php` revisado
