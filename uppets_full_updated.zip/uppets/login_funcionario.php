<?php session_start(); ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
   <meta charset="UTF-8" />
   <meta name="viewport" content="width=device-width, initial-scale=1" />
   <title>Login Atendente | UPPETS</title>

   <!-- Fontes & Ícones -->
   <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
   <script src="https://unpkg.com/lucide@latest"></script>

   <!-- CSS embutido -->
   <style>
     * { margin: 0; padding: 0; box-sizing: border-box; }

     body {
       font-family: 'Poppins', sans-serif;
       background: linear-gradient(145deg, #c4f3ff 0%, #ffffff 100%);
       min-height: 100vh;
       display: flex;
       align-items: center;
       justify-content: center;
       color: #333;
     }

     .login-wrapper {
       width: 100%;
       max-width: 410px;
       padding: 1rem;
     }

     .card {
       background: #fff;
       border-radius: 1.25rem;
       box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
       padding: 2.5rem 2rem;
     }

     .card__header {
       text-align: center;
       margin-bottom: 2rem;
     }

     .card__header .icon {
       width: 3rem;
       height: 3rem;
       color: #26a69a;
       margin-bottom: 0.5rem;
     }

     .card__header h1 {
       font-size: 1.5rem;
       font-weight: 600;
       color: #222;
     }

     .alert {
       background: #ffeaea;
       color: #c62828;
       padding: 0.75rem 1rem;
       border-radius: 0.5rem;
       margin-bottom: 1.25rem;
       font-size: 0.875rem;
     }

     .form .input-group {
       position: relative;
       margin-bottom: 1.25rem;
     }

     .form .input-group .icon {
       position: absolute;
       top: 50%;
       left: 1rem;
       transform: translateY(-50%);
       width: 1.2rem;
       height: 1.2rem;
       color: #26a69a;
     }

     .form input {
       width: 100%;
       padding: 0.9rem 1rem 0.9rem 3rem;
       border: 1px solid #cfd8dc;
       border-radius: 0.75rem;
       font-size: 0.95rem;
       transition: border-color 0.2s;
     }

     .form input:focus {
       outline: none;
       border-color: #26a69a;
       box-shadow: 0 0 0 3px rgba(38, 166, 154, 0.15);
     }

     .btn-primary {
       width: 100%;
       padding: 0.9rem 0;
       background: #26a69a;
       border: none;
       border-radius: 0.75rem;
       color: #fff;
       font-size: 1rem;
       font-weight: 600;
       cursor: pointer;
       transition: background 0.2s, transform 0.1s;
     }

     .btn-primary:hover   { background: #1c8f84; }
     .btn-primary:active  { transform: translateY(1px); }

     @media (max-width: 420px) {
       .card { padding: 2rem 1.25rem; }
     }
   </style>
</head>
<body>
   <main class="login-wrapper">
      <section class="card">
         <div class="card__header">
            <i data-lucide="user-check" class="icon"></i>
            <h1>Login do Atendente</h1>
         </div>

         <?php if (isset($_SESSION['erro'])): ?>
           <div class="alert"><?= htmlspecialchars($_SESSION['erro']); ?></div>
           <?php unset($_SESSION['erro']); ?>
         <?php endif; ?>

         <form action="verifica_login_funcionario.php" method="POST" class="form">
            <div class="input-group">
               <i data-lucide="mail" class="icon"></i>
               <input type="email" name="email" placeholder="E‑mail" required>
            </div>

            <div class="input-group">
               <i data-lucide="lock" class="icon"></i>
               <input type="password" name="senha" placeholder="Senha" required>
            </div>

            <button type="submit" class="btn-primary">Entrar</button>
         </form>
      </section>
   </main>

   <script>lucide.createIcons();</script>
</body>
</html>
