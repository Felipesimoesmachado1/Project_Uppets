
<?php
session_start();
if(!isset($_SESSION['id_funcionario'])){header('Location: login_funcionario.php'); exit;}
require 'conexao.php';
$id = intval($_GET['id'] ?? 0);
if($id){
    $conn->query("UPDATE consultas SET status='confirmada' WHERE id=$id");
}
header('Location: painel_funcionario.php');
?>
