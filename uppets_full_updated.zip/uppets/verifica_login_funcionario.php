<?php
session_start();
require 'conexao.php';

$email = trim($_POST['email'] ?? '');
$senha = $_POST['senha'] ?? '';

if (!$email || !$senha) {
    header('Location: login_funcionario.php?erro=Credenciais inválidas');
    exit;
}

$stmt = $pdo->prepare(
    'SELECT id, nome, senha FROM funcionarios WHERE email = ? LIMIT 1'
);
$stmt->execute([$email]);
$func = $stmt->fetch();

if ($func && password_verify($senha, $func['senha'])) {
    $_SESSION['id_funcionario'] = $func['id'];
    $_SESSION['nome_funcionario'] = $func['nome'];
    header('Location: painel_funcionario.php');
    exit;
}
header('Location: login_funcionario.php?erro=Credenciais inválidas');
?>
