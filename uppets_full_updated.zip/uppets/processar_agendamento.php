
<?php
session_start();
require 'conexao.php';
if(!isset($_SESSION['id_cliente'])){header('Location: login_cliente.php'); exit;}

$cliente_id    = $_SESSION['id_cliente'];
$pet_nome      = $_POST['pet_nome']      ?? '';
$data_consulta = $_POST['data_consulta'] ?? '';
$hora_consulta = $_POST['hora_consulta'] ?? '';
$descricao     = $_POST['descricao']     ?? '';

if(!$pet_nome || !$data_consulta || !$hora_consulta){
    header('Location: agendar.php?erro=Campos obrigatórios');
    exit;
}

$stmt = $conn->prepare('INSERT INTO consultas(cliente_id,pet_nome,data_consulta,hora_consulta,descricao) VALUES(?,?,?,?,?)');
$stmt->bind_param('issss',$cliente_id,$pet_nome,$data_consulta,$hora_consulta,$descricao);
$stmt->execute();

header('Location: painel_cliente.php?msg=Agendamento realizado com sucesso');
?>
