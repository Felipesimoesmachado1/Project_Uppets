<?php
session_start();
if (!isset($_SESSION['id_cliente'])) {
    header('Location: login_cliente.php');
    exit;
}

require 'conexao.php';

$id  = $_SESSION['id_cliente'];
$rs  = $conn->query(
    "SELECT * FROM consultas
     WHERE cliente_id = $id
     ORDER BY data_consulta DESC, hora_consulta DESC"
);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
   <meta charset="UTF-8" />
   <meta name="viewport" content="width=device-width, initial-scale=1" />
   <title>Histórico | UPPETS</title>

   <!-- Fonte & Ícones -->
   <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
   <script src="https://unpkg.com/lucide@latest"></script>

   <style>
     /* ---------- Base ---------- */
     * { margin: 0; padding: 0; box-sizing: border-box; }

     body {
       font-family: 'Poppins', sans-serif;
       background: linear-gradient(145deg, #c4f3ff, #ffffff);
       min-height: 100vh;
       display: flex;
       align-items: center;
       justify-content: center;
       color: #333;
     }

     /* ---------- Wrapper ---------- */
     .history-wrapper {
       width: 100%;
       max-width: 700px;
       padding: 1rem;
     }

     .card {
       background: #fff;
       border-radius: 1.25rem;
       box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
       padding: 2.5rem 2rem;
     }

     .card__header {
       text-align: center;
       margin-bottom: 2rem;
     }

     .card__header .icon {
       width: 3rem;
       height: 3rem;
       color: #26a69a;
       margin-bottom: 0.5rem;
     }

     .card__header h1 {
       font-size: 1.6rem;
       font-weight: 600;
     }

     /* ---------- Tabela ---------- */
     .table-container {
       overflow-x: auto;   /* rolagem horizontal em telas pequenas */
     }

     table {
       width: 100%;
       border-collapse: collapse;
       font-size: 0.95rem;
     }

     thead tr {
       background: #26a69a;
       color: #fff;
       text-align: left;
     }

     th, td {
       padding: 0.75rem 1rem;
       border-bottom: 1px solid #e0e0e0;
       white-space: nowrap;
     }

     tbody tr:nth-child(even) {
       background: #f7f9fa;
     }

     /* ---------- Badges de status ---------- */
     .badge {
       padding: 0.25rem 0.6rem;
       border-radius: 0.75rem;
       font-size: 0.8rem;
       font-weight: 500;
       color: #fff;
       text-transform: capitalize;
     }

     .pendente   { background: #f9a825; }   /* amarelo */
     .confirmada { background: #43a047; }   /* verde */
     .reagendada { background: #1e88e5; }   /* azul */
     .cancelada  { background: #e53935; }   /* vermelho */
     .concluída  { background: #757575; }   /* cinza */

     /* ---------- Link voltar ---------- */
     .back-link {
       margin-top: 1.5rem;
       text-align: center;
       font-size: 0.9rem;
     }

     .back-link a {
       color: #26a69a;
       text-decoration: none;
       font-weight: 500;
     }

     .back-link a:hover { text-decoration: underline; }

     @media (max-width: 500px) {
       .card {
         padding: 2rem 1.25rem;
       }
     }
   </style>
</head>
<body>
   <main class="history-wrapper">
      <section class="card">
         <div class="card__header">
            <i data-lucide="clipboard-list" class="icon"></i>
            <h1>Histórico de Consultas</h1>
         </div>

         <div class="table-container">
           <table>
              <thead>
                <tr>
                  <th>Pet</th>
                  <th>Data</th>
                  <th>Hora</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                <?php while ($r = $rs->fetch_assoc()): ?>
                  <tr>
                     <td><?= htmlspecialchars($r['pet_nome']) ?></td>
                     <td><?= date('d/m/Y', strtotime($r['data_consulta'])) ?></td>
                     <td><?= substr($r['hora_consulta'], 0, 5) ?></td>
                     <td><span class="badge <?= $r['status'] ?>">
                         <?= ucfirst($r['status']) ?></span></td>
                  </tr>
                <?php endwhile; ?>
              </tbody>
           </table>
         </div>

         <p class="back-link">
           <a href="painel_cliente.php">← Voltar ao painel</a>
         </p>
      </section>
   </main>

   <script>lucide.createIcons();</script>
</body>
</html>
