
<?php
session_start();
require 'conexao.php';

$nome  = trim($_POST['nome'] ?? '');
$email = trim($_POST['email'] ?? '');
$senha = $_POST['senha'] ?? '';

if (!$nome || !$email || !$senha) {
   header('Location: cadastro_cliente.php?erro=' . urlencode('Campos obrigatórios'));
   exit;
}

// Verifica email duplicado
$stmt = $conn->prepare('SELECT id FROM clientes WHERE email = ?');
if (!$stmt) {
    die('Erro na preparação da consulta: ' . $conn->error);
}
$stmt->bind_param('s', $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $stmt->close();
    header('Location: cadastro_cliente.php?erro=' . urlencode('E-mail já cadastrado'));
    exit;
}
$stmt->close();

$hash = password_hash($senha, PASSWORD_DEFAULT);

$stmt = $conn->prepare('INSERT INTO clientes(nome, email, senha) VALUES (?, ?, ?)');
if (!$stmt) {
    die('Erro na preparação da inserção: ' . $conn->error);
}
$stmt->bind_param('sss', $nome, $email, $hash);
if (!$stmt->execute()) {
    die('Erro ao inserir cliente: ' . $stmt->error);
}

$_SESSION['id_cliente'] = $stmt->insert_id;
$_SESSION['nome_cliente'] = $nome;

$stmt->close();
header('Location: agendar.php');
exit;
