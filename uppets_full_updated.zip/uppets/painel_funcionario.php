<?php
session_start();
if (!isset($_SESSION['id_funcionario'])) {
    header('Location: login_funcionario.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
   <meta charset="UTF-8" />
   <meta name="viewport" content="width=device-width, initial-scale=1" />
   <title>Painel do Atendente | UPPETS</title>

   <!-- Fonte & Ícones -->
   <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet" />
   <script src="https://unpkg.com/lucide@latest"></script>

   <style>
     * {
       margin: 0;
       padding: 0;
       box-sizing: border-box;
     }

     body {
       font-family: 'Poppins', sans-serif;
       background: linear-gradient(145deg, #c4f3ff, #ffffff);
       min-height: 100vh;
       display: flex;
       justify-content: center;
       align-items: center;
       color: #333;
       padding: 1rem;
     }

     .panel {
       background: #fff;
       max-width: 480px;
       width: 100%;
       padding: 2.5rem 2rem;
       border-radius: 1.25rem;
       box-shadow: 0 8px 24px rgba(0,0,0,0.08);
       text-align: center;
     }

     h1 {
       font-size: 1.8rem;
       font-weight: 600;
       color: #26a69a;
       margin-bottom: 1rem;
     }

     p {
       font-size: 1.1rem;
       margin-bottom: 2rem;
       color: #555;
     }

     a.logout-btn {
       display: inline-block;
       background-color: #26a69a;
       color: #fff;
       padding: 0.9rem 2rem;
       font-weight: 600;
       border-radius: 0.75rem;
       text-decoration: none;
       font-size: 1rem;
       transition: background-color 0.2s ease;
     }

     a.logout-btn:hover {
       background-color: #1c8f84;
     }
   </style>
</head>
<body>
   <main class="panel">
      <h1>Bem‑vindo, <?= htmlspecialchars($_SESSION['nome_funcionario']) ?>!</h1>
      <p>Você está logado no painel do atendente.</p>
      <a href="logout.php" class="logout-btn">Sair</a>
   </main>

   <script>lucide.createIcons();</script>
</body>
</html>
