/* =======================  Banco & Tabelas  ======================= */
CREATE DATABASE IF NOT EXISTS clinicadb
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE clinicadb;

/* ---- Clientes --------------------------------------------------- */
CREATE TABLE IF NOT EXISTS clientes (
    id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nome       VARCHAR(100) NOT NULL,
    email      VARCHAR(100) NOT NULL UNIQUE,
    senha      VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP
);

/* ---- Funcionários ----------------------------------------------- */
CREATE TABLE IF NOT EXISTS funcionarios (
    id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nome       VARCHAR(100) NOT NULL,
    email      VARCHAR(100) NOT NULL UNIQUE,
    senha      VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP
);

/* ---- Consultas --------------------------------------------------- */
CREATE TABLE IF NOT EXISTS consultas (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    cliente_id    INT UNSIGNED NOT NULL,
    pet_nome      VARCHAR(100) NOT NULL,
    data_consulta DATE NOT NULL,
    hora_consulta TIME NOT NULL,
    descricao     VARCHAR(255),
    status        ENUM('pendente','confirmada','reagendada','cancelada')
                 DEFAULT 'pendente',
    comentarios   VARCHAR(255),
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_consulta_cliente
        FOREIGN KEY (cliente_id) REFERENCES clientes(id)
        ON DELETE CASCADE ON UPDATE CASCADE
);

/* ---- Usuário admin padrão --------------------------------------- */
/* senha original: senha123 */
INSERT IGNORE INTO funcionarios (nome,email,senha) VALUES
('Administrador','admin@clinica.com',
'$2y$10$e0NR1uW5MxkEeMbZPqFkOu8xF6uO5XQd2C.l2dYI/uY4LzYK9i4K6');
