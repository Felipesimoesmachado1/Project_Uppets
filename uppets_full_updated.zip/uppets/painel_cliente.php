<?php
session_start();
if (!isset($_SESSION['id_cliente'])) {
   header('Location: login_cliente.php');
   exit();
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
   <meta charset="UTF-8" />
   <meta name="viewport" content="width=device-width, initial-scale=1" />
   <title>Painel do Cliente | UPPETS</title>

   <!-- Fontes & Ícones -->
   <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
   <script src="https://unpkg.com/lucide@latest"></script>

   <style>
     * { margin: 0; padding: 0; box-sizing: border-box; }

     body {
       font-family: 'Poppins', sans-serif;
       background: linear-gradient(145deg, #c4f3ff 0%, #ffffff 100%);
       min-height: 100vh;
       display: flex;
       align-items: center;
       justify-content: center;
       color: #333;
       padding: 1rem;
     }

     /* ------ Card principal ------ */
     .panel {
       background: #fff;
       border-radius: 1.25rem;
       box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
       max-width: 600px;
       width: 100%;
       padding: 2.5rem 2rem;
       text-align: center;
     }

     .panel h1 {
       font-size: 1.6rem;
       font-weight: 600;
       margin-bottom: 2rem;
     }

     /* ------ Navegação ------ */
     .nav-links {
       display: flex;
       flex-wrap: wrap;
       justify-content: center;
       gap: 0.75rem;
       margin-bottom: 2rem;
     }

     .nav-links a {
       display: flex;
       align-items: center;
       gap: 0.4rem;
       padding: 0.7rem 1.2rem;
       background: #26a69a;
       color: #fff;
       font-size: 0.95rem;
       font-weight: 500;
       text-decoration: none;
       border-radius: 0.75rem;
       transition: background 0.2s, transform 0.1s;
     }

     .nav-links a:hover   { background: #1c8f84; }
     .nav-links a:active  { transform: translateY(1px); }

     /* Ícones nos links (Lucide) */
     .nav-links a .icon {
       width: 1.1rem;
       height: 1.1rem;
     }

     /* ------ Conteúdo dinâmico ------ */
     #conteudo {
       text-align: left;
       font-size: 0.95rem;
     }

     @media (max-width: 540px) {
       .panel { padding: 2rem 1.25rem; }
       .nav-links { gap: 0.5rem; }
       .nav-links a { padding: 0.6rem 1rem; font-size: 0.9rem; }
     }
   </style>
</head>
<body>
   <main class="panel">
      <h1>Bem‑vindo, <?= htmlspecialchars($_SESSION['nome_cliente']); ?>!</h1>

      <nav class="nav-links">
         <a href="agendar.php">
            <i data-lucide="calendar-plus" class="icon"></i>
            Agendar Consulta
         </a>
         <a href="historico.php">
            <i data-lucide="clipboard-list" class="icon"></i>
            Histórico
         </a>
         <a href="logout.php">
            <i data-lucide="log-out" class="icon"></i>
            Sair
         </a>
      </nav>

      <div id="conteudo">
         <!-- Conteúdo dinâmico pode ser carregado aqui se desejar -->
         <p>Escolha uma opção acima para começar.</p>
      </div>
   </main>

   <script>lucide.createIcons();</script>
</body>
</html>
