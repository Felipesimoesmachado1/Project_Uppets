<?php session_start(); ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
   <meta charset="UTF-8" />
   <meta name="viewport" content="width=device-width, initial-scale=1" />
   <title>Cadastro Cliente | UPPETS</title>

   <!-- Fontes e Ícones -->
   <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
   <script src="https://unpkg.com/lucide@latest"></script>

   <!-- Estilo embutido -->
   <style>
     * {
       margin: 0;
       padding: 0;
       box-sizing: border-box;
     }

     body {
       font-family: 'Poppins', sans-serif;
       background: linear-gradient(145deg, #c4f3ff, #ffffff);
       min-height: 100vh;
       display: flex;
       align-items: center;
       justify-content: center;
       color: #333;
     }

     .cadastro-wrapper {
       width: 100%;
       max-width: 410px;
       padding: 1rem;
     }

     .card {
       background: #fff;
       border-radius: 1.25rem;
       box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
       padding: 2.5rem 2rem;
     }

     .card__header {
       text-align: center;
       margin-bottom: 2rem;
     }

     .card__header .icon {
       width: 3rem;
       height: 3rem;
       color: #26a69a;
       margin-bottom: 0.5rem;
     }

     .card__header h1 {
       font-size: 1.5rem;
       font-weight: 600;
       color: #222;
     }

     .card__header p {
       font-size: 0.9rem;
       color: #555;
       margin-top: 0.25rem;
     }

     .form .input-group {
       position: relative;
       margin-bottom: 1.25rem;
     }

     .form .input-group .icon {
       position: absolute;
       top: 50%;
       left: 1rem;
       transform: translateY(-50%);
       width: 1.2rem;
       height: 1.2rem;
       color: #26a69a;
     }

     .form input {
       width: 100%;
       padding: 0.9rem 1rem 0.9rem 3rem;
       border: 1px solid #cfd8dc;
       border-radius: 0.75rem;
       font-size: 0.95rem;
       transition: border-color 0.2s;
     }

     .form input:focus {
       outline: none;
       border-color: #26a69a;
       box-shadow: 0 0 0 3px rgba(38, 166, 154, 0.15);
     }

     .btn-primary {
       width: 100%;
       padding: 0.9rem 0;
       background: #26a69a;
       border: none;
       border-radius: 0.75rem;
       color: #fff;
       font-size: 1rem;
       font-weight: 600;
       cursor: pointer;
       transition: background 0.2s, transform 0.1s;
     }

     .btn-primary:hover {
       background: #1c8f84;
     }

     .btn-primary:active {
       transform: translateY(1px);
     }

     .login-link {
       text-align: center;
       margin-top: 1rem;
       font-size: 0.9rem;
     }

     .login-link a {
       color: #26a69a;
       font-weight: 500;
       text-decoration: none;
     }

     .login-link a:hover {
       text-decoration: underline;
     }

     @media (max-width: 420px) {
       .card {
         padding: 2rem 1.25rem;
       }
     }
   </style>
</head>
<body>
    <main class="cadastro-wrapper">
        <section class="card">
            <div class="card__header">
                <i data-lucide="paw-print" class="icon"></i>
                <h1>Cadastre-se na UPPETS</h1>
                <p>Crie sua conta para agendar consultas para seu pet!</p>
            </div>

            <form action="processar_cadastro_cliente.php" method="POST" class="form">
                <div class="input-group">
                    <i data-lucide="user" class="icon"></i>
                    <input type="text" name="nome" placeholder="Nome completo" required>
                </div>

                <div class="input-group">
                    <i data-lucide="mail" class="icon"></i>
                    <input type="email" name="email" placeholder="E‑mail" required>
                </div>

                <div class="input-group">
                    <i data-lucide="lock" class="icon"></i>
                    <input type="password" name="senha" placeholder="Senha" required>
                </div>

                <button type="submit" class="btn-primary">Cadastrar</button>

                <p class="login-link">
                    Já tem conta? <a href="login_cliente.php">Entrar</a>
                </p>
            </form>
        </section>
    </main>

    <script>lucide.createIcons();</script>
</body>
</html>
