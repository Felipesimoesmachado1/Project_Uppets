<?php
header('Content-Type: application/json');
require_once '../conexao.php';

$sql = 'SELECT status, COUNT(*) AS total
        FROM consultas
        GROUP BY status';
$result = $conn->query($sql);

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[$row['status']] = (int)$row['total'];
}
echo json_encode($data);
?>
