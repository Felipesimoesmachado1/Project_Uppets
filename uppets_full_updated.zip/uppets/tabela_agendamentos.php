<?php
require_once 'conexao.php';
$filtroStatus = $_GET['status'] ?? '';
$busca        = $_GET['q'] ?? '';
$where = [];
if ($filtroStatus) $where[] = "c.status='$filtroStatus'";
if ($busca) {
    $busca = $conn->real_escape_string($busca);
    $where[] = "(cl.nome LIKE '%$busca%' OR c.pet_nome LIKE '%$busca%')";
}
$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';
$sql = "SELECT c.*, cl.nome AS cliente
        FROM consultas c
        JOIN clientes cl ON cl.id=c.cliente_id
        $whereSql
        ORDER BY data_consulta, hora_consulta";
$r = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Consultas | UPPETS</title>

  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet" />
  <style>
    * {
      margin: 0; padding: 0; box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
    }
    body {
      background: linear-gradient(145deg, #c4f3ff, #ffffff);
      min-height: 100vh;
      padding: 2rem;
      color: #333;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      box-shadow: 0 6px 18px rgba(0,0,0,0.08);
      border-radius: 0.75rem;
      overflow: hidden;
      background: #fff;
    }
    thead tr {
      background-color: #26a69a;
      color: #fff;
      font-weight: 600;
    }
    th, td {
      padding: 0.85rem 1rem;
      text-align: left;
      border-bottom: 1px solid #e0e0e0;
      white-space: nowrap;
    }
    tbody tr:nth-child(even) {
      background: #f7f9fa;
    }
    tbody tr:hover {
      background: #e0f2f1;
      cursor: default;
    }
    .badge {
      padding: 0.25rem 0.6rem;
      border-radius: 0.75rem;
      font-size: 0.8rem;
      font-weight: 600;
      color: #fff;
      text-transform: capitalize;
      display: inline-block;
      min-width: 70px;
      text-align: center;
    }
    .pendente   { background: #f9a825; } /* amarelo */
    .confirmada { background: #43a047; } /* verde */
    .reagendada { background: #1e88e5; } /* azul */
    .cancelada  { background: #e53935; } /* vermelho */
    .concluída  { background: #757575; } /* cinza */

    /* Botões */
    .btn {
      background: #26a69a;
      color: #fff;
      border: none;
      border-radius: 0.5rem;
      padding: 0.3rem 0.6rem;
      margin-right: 0.3rem;
      font-size: 1rem;
      font-weight: 600;
      text-decoration: none;
      cursor: pointer;
      transition: background-color 0.2s;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      user-select: none;
    }
    .btn:hover {
      background: #1c8f84;
    }
    .btn.reagendar {
      background: #1e88e5;
    }
    .btn.reagendar:hover {
      background: #1565c0;
    }

    /* Modal */
    .modal {
      display: none;
      position: fixed;
      top: 0; left: 0; right: 0; bottom: 0;
      background-color: rgba(0,0,0,0.4);
      z-index: 9999;
      align-items: center;
      justify-content: center;
      padding: 1rem;
    }
    .modal form {
      background: #fff;
      border-radius: 1rem;
      max-width: 400px;
      width: 100%;
      padding: 2rem;
      box-shadow: 0 8px 24px rgba(0,0,0,0.15);
      display: flex;
      flex-direction: column;
      gap: 1rem;
    }
    .modal input[type="date"],
    .modal input[type="time"],
    .modal textarea {
      padding: 0.7rem 1rem;
      border: 1px solid #ccc;
      border-radius: 0.75rem;
      font-size: 1rem;
      resize: vertical;
      font-family: 'Poppins', sans-serif;
    }
    .modal textarea {
      min-height: 80px;
    }
    .modal button[type="submit"] {
      background: #26a69a;
      color: #fff;
      border: none;
      border-radius: 0.75rem;
      padding: 0.9rem 0;
      font-weight: 600;
      cursor: pointer;
      transition: background-color 0.2s;
      font-size: 1rem;
    }
    .modal button[type="submit"]:hover {
      background: #1c8f84;
    }
    .modal button.close-btn {
      background: transparent;
      border: none;
      color: #888;
      font-weight: 600;
      cursor: pointer;
      text-align: right;
      font-size: 1.1rem;
      margin-top: -0.5rem;
      align-self: flex-end;
    }
    .modal button.close-btn:hover {
      color: #444;
    }

    /* Responsividade */
    @media (max-width: 480px) {
      th, td {
        font-size: 0.85rem;
        padding: 0.5rem 0.7rem;
      }
      .btn {
        font-size: 0.85rem;
        padding: 0.25rem 0.5rem;
      }
      .modal form {
        padding: 1.5rem 1rem;
      }
    }
  </style>
</head>
<body>

<table>
  <thead>
    <tr>
      <th>ID</th>
      <th>Cliente</th>
      <th>Pet</th>
      <th>Data</th>
      <th>Hora</th>
      <th>Status</th>
      <th>Ações</th>
    </tr>
  </thead>
  <tbody>
  <?php while($c=$r->fetch_assoc()): ?>
    <tr>
      <td><?= $c['id'] ?></td>
      <td><?= htmlspecialchars($c['cliente']) ?></td>
      <td><?= htmlspecialchars($c['pet_nome']) ?></td>
      <td><?= date('d/m/Y', strtotime($c['data_consulta'])) ?></td>
      <td><?= substr($c['hora_consulta'], 0, 5) ?></td>
      <td><span class="badge <?= $c['status'] ?>"><?= ucfirst($c['status']) ?></span></td>
      <td>
         <a class="btn" href="confirmar_consulta.php?id=<?= $c['id'] ?>" title="Confirmar">✔</a>
         <a class="btn" href="cancelar_consulta.php?id=<?= $c['id'] ?>" title="Cancelar">✖</a>
         <button class="btn reagendar" data-id="<?= $c['id'] ?>" title="Reagendar">⟳</button>
      </td>
    </tr>
  <?php endwhile; ?>
  </tbody>
</table>

<!-- Modal de reagendamento -->
<div id="modal-reagendar" class="modal" aria-hidden="true" role="dialog" aria-labelledby="modalTitle" aria-modal="true">
  <form action="processar_reagendamento.php" method="POST" aria-describedby="modalDesc">
     <h2 id="modalTitle" style="margin-bottom: 1rem; color:#26a69a;">Reagendar Consulta</h2>
     <input type="hidden" name="id" id="consultaId">
     <label for="dataConsulta" style="font-weight:600; margin-bottom:0.3rem;">Nova Data</label>
     <input type="date" id="dataConsulta" name="data_consulta" required>
     <label for="horaConsulta" style="font-weight:600; margin-bottom:0.3rem;">Nova Hora</label>
     <input type="time" id="horaConsulta" name="hora_consulta" required>
     <label for="comentarios" style="font-weight:600; margin-bottom:0.3rem;">Comentário Opcional</label>
     <textarea id="comentarios" name="comentarios" placeholder="Comentário opcional"></textarea>
     <button type="submit">Salvar</button>
     <button type="button" class="close-btn" aria-label="Fechar modal" onclick="fecharModal()">✖ Fechar</button>
  </form>
</div>

<script>
  const modal = document.getElementById('modal-reagendar');
  const consultaIdInput = document.getElementById('consultaId');

  document.querySelectorAll('.reagendar').forEach(btn => {
    btn.onclick = e => {
      e.preventDefault();
      consultaIdInput.value = btn.dataset.id;
      modal.style.display = 'flex';
      document.getElementById('dataConsulta').focus();
    };
  });

  function fecharModal() {
    modal.style.display = 'none';
  }

  // Fecha modal ao clicar fora do formulário
  modal.addEventListener('click', e => {
    if (e.target === modal) fecharModal();
  });

  // Fecha modal com ESC
  document.addEventListener('keydown', e => {
    if (e.key === "Escape" && modal.style.display === 'flex') {
      fecharModal();
    }
  });
</script>

</body>
</html>
