fetch('api/stats_consultas.php')
  .then(r=>r.json())
  .then(d=>{
     document.getElementById('qty-pend').textContent = d.pendente ?? 0;
     document.getElementById('qty-hoje').textContent = d.hoje ?? 0;
     document.getElementById('qty-canc').textContent = d.cancelada ?? 0;
     new Chart(document.getElementById('grafico-status'), {
       type:'doughnut',
       data:{labels:['Pendentes','Confirmadas','Reagendadas','Canceladas'],
             datasets:[{data:[d.pendente,d.confirmada,d.reagendada,d.cancelada]}]},
       options:{plugins:{legend:{position:'bottom'}}}
     });
  });
