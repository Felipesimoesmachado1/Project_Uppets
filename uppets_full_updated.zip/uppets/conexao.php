<?php
// conexao.php – PDO + MySQLi
$host = 'localhost';
$db   = 'clinicadb';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

/* ---------- PDO ---------- */
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];
try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$db;charset=$charset",
        $user,
        $pass,
        $options
    );
} catch (PDOException $e) {
    die("Erro na conexão PDO: " . $e->getMessage());
}

/* ---------- MySQLi ---------- */
$mysqli = new mysqli($host, $user, $pass, $db);
if ($mysqli->connect_error) {
    die("Erro na conexão MySQLi: " . $mysqli->connect_error);
}
$mysqli->set_charset($charset);

/* Alias */
$conn = $mysqli;
?>
