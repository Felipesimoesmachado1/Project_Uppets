<?php
session_start();
if (!isset($_SESSION['id_cliente'])) {
    header('Location: login_cliente.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
   <meta charset="UTF-8" />
   <meta name="viewport" content="width=device-width, initial-scale=1" />
   <title>Agendar Consulta | UPPETS</title>

   <!-- Fontes & Ícones -->
   <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
   <script src="https://unpkg.com/lucide@latest"></script>

   <!-- Estilo embutido -->
   <style>
     * { margin: 0; padding: 0; box-sizing: border-box; }

     body {
       font-family: 'Poppins', sans-serif;
       background: linear-gradient(145deg, #c4f3ff, #ffffff);
       min-height: 100vh;
       display: flex;
       align-items: center;
       justify-content: center;
       color: #333;
     }

     .agendamento-wrapper {
       width: 100%;
       max-width: 450px;
       padding: 1rem;
     }

     .card {
       background: #fff;
       border-radius: 1.25rem;
       box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
       padding: 2.5rem 2rem;
     }

     .card__header {
       text-align: center;
       margin-bottom: 2rem;
     }

     .card__header .icon {
       width: 3rem;
       height: 3rem;
       color: #26a69a;
       margin-bottom: 0.5rem;
     }

     .card__header h1 {
       font-size: 1.5rem;
       font-weight: 600;
       color: #222;
     }

     .form .input-group {
       position: relative;
       margin-bottom: 1.25rem;
     }

     .form .input-group .icon {
       position: absolute;
       top: 50%;
       left: 1rem;
       transform: translateY(-50%);
       width: 1.2rem;
       height: 1.2rem;
       color: #26a69a;
     }

     .form input,
     .form textarea {
       width: 100%;
       padding: 0.9rem 1rem 0.9rem 3rem;
       border: 1px solid #cfd8dc;
       border-radius: 0.75rem;
       font-size: 0.95rem;
       transition: border-color 0.2s;
       resize: vertical;
     }

     .form input:focus,
     .form textarea:focus {
       outline: none;
       border-color: #26a69a;
       box-shadow: 0 0 0 3px rgba(38, 166, 154, 0.15);
     }

     .btn-primary {
       width: 100%;
       padding: 0.9rem 0;
       background: #26a69a;
       border: none;
       border-radius: 0.75rem;
       color: #fff;
       font-size: 1rem;
       font-weight: 600;
       cursor: pointer;
       transition: background 0.2s, transform 0.1s;
     }

     .btn-primary:hover { background: #1c8f84; }
     .btn-primary:active { transform: translateY(1px); }

     .back-link {
       display: block;
       text-align: center;
       margin-top: 1rem;
       font-size: 0.9rem;
     }

     .back-link a {
       color: #26a69a;
       text-decoration: none;
       font-weight: 500;
     }

     .back-link a:hover { text-decoration: underline; }

     @media (max-width: 460px) {
       .card { padding: 2rem 1.25rem; }
     }
   </style>
</head>
<body>
   <main class="agendamento-wrapper">
      <section class="card">
         <div class="card__header">
            <i data-lucide="calendar-check-2" class="icon"></i>
            <h1>Novo Agendamento</h1>
         </div>

         <form action="processar_agendamento.php" method="POST" class="form">
            <div class="input-group">
               <i data-lucide="dog" class="icon"></i>
               <input type="text" name="pet_nome" placeholder="Nome do Pet" required>
            </div>

            <div class="input-group">
               <i data-lucide="calendar-days" class="icon"></i>
               <input type="date" name="data_consulta"
                      required min="<?php echo date('Y-m-d'); ?>">
            </div>

            <div class="input-group">
               <i data-lucide="clock" class="icon"></i>
               <input type="time" name="hora_consulta" required>
            </div>

            <div class="input-group">
               <i data-lucide="edit" class="icon"></i>
               <textarea name="descricao" rows="3"
                         placeholder="Motivo / Observações" required></textarea>
            </div>

            <button type="submit" class="btn-primary">Agendar</button>
         </form>

         <p class="back-link"><a href="painel_cliente.php">← Voltar ao painel</a></p>
      </section>
   </main>

   <script>lucide.createIcons();</script>
</body>
</html>
